# Kit grafico UNESCO IA – Guida di stile

*Kit per presentazioni, dispense e pagine web sui quadri UNESCO 2024 delle competenze sull'IA (studenti e docenti) · a cura di Antonio Scaramuzzino*

Il kit riprende l'identità della sezione UNESCO del ProfTecnologIA Framework: banda petrolio, accenti zafferano e acqua, un colore per ciascun aspetto di competenza. L'identità è originale: **non usa il logo UNESCO né elementi grafici istituzionali**.

---

## Contenuto del kit

| File o cartella | Uso |
|---|---|
| UNESCO_Template_Presentazione.pptx | Modello PowerPoint 16:9 con 15 layout e slide di esempio |
| UNESCO_Template_Dispensa.docx | Modello Word A4 per dispense, con stili e componenti |
| img/ | Logo di sezione, icone degli aspetti (colore, bianche, in cerchio), barre dei livelli, archi decorativi, simbolo dei sei colori, matrici aspetti × livelli; in img/svg le icone vettoriali originali |
| font/ | Outfit e Source Sans 3 (licenza SIL OFL, gratuiti) |
| _sorgenti/ | Script di generazione e dati (vedi LEGGIMI.txt) |

Materiali già pronti, costruiti con il kit: **UNESCO_IA_Studenti.pptx** e **UNESCO_IA_Docenti.pptx** (cartella Presentazioni), **UNESCO_IA_Dispensa.docx** (cartella Dispense), ciascuno con il testo in .md.

## 1. Licenza: cosa si può e non si può fare

- **Testi**: i quadri UNESCO (2024) sono rilasciati con licenza **CC BY-SA 3.0 IGO**. Traduzioni e adattamenti vanno distribuiti con la stessa licenza, citando la fonte. I modelli lo fanno già nel piè di pagina e nella slide di chiusura.
- **Clausola obbligatoria di traduzione non ufficiale** (in chiusura di ogni materiale): «Questa traduzione non è stata realizzata dall'UNESCO e non deve essere considerata una traduzione ufficiale dell'UNESCO. L'UNESCO non è responsabile del contenuto né di eventuali errori di questa traduzione.» Versione inglese: «This translation was not created by UNESCO and should not be considered an official UNESCO translation. UNESCO shall not be liable for any content or error in this translation.»
- **Esclusi**: logo UNESCO, emblema e qualunque elemento grafico istituzionale; nessuna formula che lasci intendere un'approvazione dell'UNESCO.
- **Corrispondenze tra UNESCO e AILit** e proposte didattiche: sono del formatore e vanno sempre etichettate così (pillola «Proposta del formatore» nelle slide, «proposta del formatore, non contenuto UNESCO» nelle dispense).
- **Grafica del kit** (icone, logo di sezione, archi, matrici): elaborazione originale del ProfTecnologIA Framework.

## 2. Palette

Il petrolio domina; zafferano e acqua sono accenti. Ogni aspetto di competenza ha un colore: in una slide dedicata a un aspetto si usa solo quel colore.

| Nome | HEX | Ruolo |
|---|---|---|
| Petrolio | #0F3D5E | Copertine, aperture di capitolo, titoli, intestazioni di tabella |
| Petrolio scuro | #0A2C44 | Varianti scure (web) |
| Zafferano | #F2B134 | Accento, numeri di capitolo, barre dei livelli (mai testo bianco sopra: usare #1E1A10) |
| Acqua | #5CC8C2 | Accento secondario (archi) |
| Celeste | #8FD3E8 | Testo secondario su petrolio |
| Mentalità incentrata sull'essere umano | #0E7C86 · tinta #DDF3F3 | Aspetto |
| Etica dell'IA | #A65A1A · tinta #F8E9DA | Aspetto |
| Tecniche / Fondamenti e applicazioni dell'IA | #3D4DB7 · tinta #E3E6F8 | Aspetto (stesso colore nei due quadri) |
| Progettazione di sistemi di IA | #A12C6B · tinta #F6E0EC | Aspetto (solo studenti) |
| Pedagogia dell'IA | #2F7D32 · tinta #E0F0E1 | Aspetto (solo docenti) |
| IA per lo sviluppo professionale | #6B4BB8 · tinta #ECE5F8 | Aspetto (solo docenti) |
| Testo · grigio · linee | #14262F · #5B6C74 · #D3DEE2 | Neutri |
| Fondi | #F3F6F7 · #EAF0F2 · zafferano chiaro #FCEFD2 · acqua chiara #DDF4F2 | Card, riquadri |

Sui colori pieni degli aspetti il testo è bianco; sulle tinte chiare il codice e il livello sono nel colore dell'aspetto e il titolo in petrolio.

## 3. Tipografia

| Elemento | Font | Presentazione | Dispensa |
|---|---|---|---|
| Titoli, numeri, codici, etichette | Outfit Bold | 32–44 pt (sezioni 40 pt, numero 110 pt) | 14–28 pt |
| Corpo, elenchi | Source Sans 3 | 14–18 pt | 10,5 pt giustificato |
| Citazioni | Outfit Italic, petrolio | 26 pt | 11,5 pt con filetto zafferano |
| Note, fonti, piè di pagina | Source Sans 3 Italic, grigio | 9–11 pt | 7–8,5 pt |

I file in font/ coprono il set latino (italiano compreso). Per altre lingue scaricare le famiglie complete da Google Fonts. Installazione su Windows: selezionare tutti i .ttf, tasto destro, «Installa per tutti gli utenti»; su Mac: doppio clic, «Installa». Prima di inviare un .pptx: File, Opzioni, Salva, «Incorpora i caratteri nel file».

## 4. Componenti grafici

| Componente | Descrizione |
|---|---|
| Logo di sezione | Cerchio petrolio con archi zafferano e acqua: copertina e piè di pagina |
| Archi | Motivo decorativo tratto dal logo: copertina, aperture petrolio, citazione, chiusura |
| Simbolo dei sei colori | Sei punti nei colori degli aspetti sopra il titolo di ogni slide e sotto il titolo dei capitoli della dispensa |
| Icone degli aspetti | Lineari 48×48; tre varianti: nel colore dell'aspetto, bianche (su pannelli colorati), in cerchio pieno |
| Barre dei livelli | Tre barre a gradino in zafferano: 1, 2 o 3 piene = primo, secondo, terzo livello |
| Scheda blocco | Card nella tinta chiara dell'aspetto, barre del livello, codice e livello nel colore dell'aspetto, titolo petrolio |
| Matrice | Aspetti (righe colorate con icona) × livelli (intestazioni petrolio); codici dei blocchi come nell'originale |
| Quadrato numerato | Quadrato arrotondato petrolio per elenchi e principi |
| Pillole | Petrolio (Studenti · AI CFS), zafferano (Docenti · AI CFT), grigio-azzurro (Proposta del formatore) |
| Riquadri | Zafferano chiaro (attività, proposte), acqua chiara (avvertenze, definizioni), grigio-azzurro (approfondimenti) |

Codici dei blocchi: studenti 4.livello.aspetto (es. 4.2.3 = Applicare, Tecniche e applicazioni); docenti aspetto.livello (es. 3.2 = Fondamenti e applicazioni, Approfondire).

## 5. Layout PowerPoint

| Layout | Uso |
|---|---|
| UNESCO Copertina | Titolo, sottotitolo, autore su petrolio con archi |
| UNESCO Sezione Petrolio | Apertura di capitolo generale (numero zafferano) |
| UNESCO Sezione Aspetto mentalita / etica / tecniche / progettazione / pedagogia / sviluppo | Apertura di capitolo dedicato a un aspetto; «tecniche» vale anche per Fondamenti e applicazioni |
| UNESCO Contenuto | Titolo e testo |
| UNESCO Due colonne | Testo a sinistra, figura o box a destra |
| UNESCO Definizione | Contesto a sinistra, pannello grigio-azzurro a destra |
| UNESCO Box | Riquadro zafferano chiaro per attività o approfondimento |
| UNESCO Solo titolo | Base per composizioni (matrice, schede blocco, principi) |
| UNESCO Citazione | Citazione con fonte |
| UNESCO Chiusura | Contatti, fonti, licenza e clausola su petrolio |

## 6. Regole d'uso dei contenuti

- Citare fedelmente la traduzione; se si riassume o si riporta solo la prima frase, dichiararlo nella riga della fonte.
- Indicare sempre quadro e blocco (es. «AI CFS, blocco 4.1.1»).
- Non inventare obiettivi, metodi o attività attribuendoli all'UNESCO: le proposte proprie vanno etichettate.

## 7. Fonti da citare

- UNESCO (2024). *AI competency framework for students*. Paris, UNESCO. https://doi.org/10.54675/JKJB9835
- UNESCO (2024). *AI competency framework for teachers*. Paris, UNESCO. https://doi.org/10.54675/ZJTE2084
- Licenza CC BY-SA 3.0 IGO. Traduzione italiana non ufficiale: ProfTecnologIA Framework, sezione UNESCO (proftecnologia-framework.vercel.app/unesco/).
