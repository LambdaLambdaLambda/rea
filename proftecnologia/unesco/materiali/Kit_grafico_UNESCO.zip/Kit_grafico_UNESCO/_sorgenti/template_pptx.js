// Template PowerPoint del Kit grafico UNESCO IA: una slide di esempio per ogni layout e componente
// uso: node template_pptx.js [uscita.pptx]
const { applyTheme } = require(process.env.APPLY_THEME || "/root/.claude/skills/synced/c3460612-16fc-48c3-b005-f4c44099b8ff_a22df8e7-4c19-4401-b3d1-06128ef1142c/pptx/scripts/apply_theme.js");
const { makeKit } = require("./kit_pptx.js");
const { ATTR, FONTI, CLAUSOLA, LICENZA, ORDINE, LIVELLI } = require("./palette.js");
const OUT = process.argv[2] || __dirname + "/../UNESCO_Template_Presentazione.pptx";
const K = makeKit({ title: "Template UNESCO IA", author: "Antonio Scaramuzzino", attr: ATTR });
const { pres, T, numSq, pill, card, icon, livello, fonte, img, HEX, ASP, DIMS } = K;
const N = (s, t) => s.addNotes(t);

let s = pres.addSlide({ masterName: "UNESCO Copertina" });
s.addText("Titolo del percorso sui quadri UNESCO", { placeholder: "title" });
s.addText("Sottotitolo · destinatari", { placeholder: "sottotitolo" });
s.addText([{ text: "Nome Cognome", options: { bold: true, breakLine: true } }, { text: "Ente · gg mese aaaa" }], { placeholder: "autore" });
N(s, "Layout: UNESCO Copertina. Fondo petrolio, archi zafferano e acqua (motivo del logo di sezione). Nessun logo UNESCO.");

s = pres.addSlide({ masterName: "UNESCO Sezione Petrolio" });
s.addText("01", { placeholder: "numero" }); s.addText("Titolo della sezione", { placeholder: "title" }); s.addText("Domanda guida", { placeholder: "sottotitolo" });
N(s, "Layout: UNESCO Sezione Petrolio, per capitoli generali. Per un capitolo dedicato a un aspetto usare UNESCO Sezione Aspetto <nome>.");
["mentalita", "etica", "tecniche", "progettazione", "pedagogia", "sviluppo"].forEach((k, i) => {
  s = pres.addSlide({ masterName: "UNESCO Sezione Aspetto " + k });
  s.addText(String(i + 1).padStart(2, "0"), { placeholder: "numero" });
  s.addText(k === "tecniche" ? "Tecniche / Fondamenti e applicazioni dell'IA" : ASP[k].nome, { placeholder: "title" });
  s.addText("Aspetto di competenza", { placeholder: "sottotitolo" });
  N(s, "Layout: UNESCO Sezione Aspetto " + k + (k === "tecniche" ? ". Vale sia per «Tecniche e applicazioni» (studenti) sia per «Fondamenti e applicazioni» (docenti)." : ""));
});

s = pres.addSlide({ masterName: "UNESCO Contenuto" });
s.addText("Titolo della slide", { placeholder: "title" });
s.addText([{ text: "Primo punto dell'elenco", options: { bullet: true, breakLine: true } }, { text: "Secondo punto", options: { bullet: true, breakLine: true } }, { text: "Terzo punto", options: { bullet: true } }], { placeholder: "body" });

s = pres.addSlide({ masterName: "UNESCO Due colonne" });
s.addText("Testo e figura", { placeholder: "title" });
s.addText("Testo a sinistra; a destra una figura del kit, per esempio la matrice aspetti × livelli del quadro per gli studenti.", { placeholder: "body" });
img(s, "matrice_studenti.png", 7.1, 1.6, 5.63, 5.63 * DIMS.matrice_studenti[1] / DIMS.matrice_studenti[0]);

s = pres.addSlide({ masterName: "UNESCO Definizione" });
s.addText("Titolo", { placeholder: "title" }); s.addText("Testo di contesto.", { placeholder: "body" });
s.addText("Definizione", { placeholder: "def_titolo" });
T(s, "«Testo citato fedelmente dalla traduzione.»", { x: 7.45, y: 1.5, w: 5.4, h: 4.1, fontSize: 18, color: HEX.petrolio, fontFace: "Outfit", valign: "top" });
s.addText("Fonte: quadro e blocco", { placeholder: "fonte" });

s = pres.addSlide({ masterName: "UNESCO Box" });
s.addText("Riquadro", { placeholder: "title" }); s.addText("Attività o approfondimento", { placeholder: "box_titolo" }); s.addText("Testo del riquadro su fondo zafferano chiaro.", { placeholder: "body" });

s = pres.addSlide({ masterName: "UNESCO Solo titolo" });
s.addText("Componenti: aspetti, livelli, blocchi", { placeholder: "title" });
T(s, "Aspetti di competenza (icona in cerchio)", { x: 0.6, y: 1.5, w: 6.4, h: 0.4, fontSize: 16, bold: true, color: HEX.petrolio, fontFace: "Outfit" });
["mentalita", "etica", "tecniche", "progettazione", "pedagogia", "sviluppo"].forEach((k, i) => icon(s, k, 0.6 + i * 0.95, 2.0, 0.75, "cerchio"));
T(s, "Livelli di progressione (barre zafferano)", { x: 0.6, y: 3.05, w: 6.4, h: 0.4, fontSize: 16, bold: true, color: HEX.petrolio, fontFace: "Outfit" });
LIVELLI.studenti.forEach((l, i) => { livello(s, i + 1, 0.6 + i * 2.1, 3.6, 0.4); T(s, l, { x: 1.3 + i * 2.1, y: 3.6, w: 1.4, h: 0.4, fontSize: 14, bold: true, valign: "middle" }); });
LIVELLI.docenti.forEach((l, i) => { livello(s, i + 1, 0.6 + i * 2.1, 4.2, 0.4); T(s, l, { x: 1.3 + i * 2.1, y: 4.2, w: 1.4, h: 0.4, fontSize: 14, bold: true, valign: "middle" }); });
T(s, "Etichette", { x: 0.6, y: 4.95, w: 6, h: 0.4, fontSize: 16, bold: true, color: HEX.petrolio, fontFace: "Outfit" });
pill(s, "Studenti · AI CFS", 0.6, 5.45, 2.0, HEX.petrolio, "FFFFFF"); pill(s, "Docenti · AI CFT", 2.75, 5.45, 2.0, HEX.zafferano, HEX.zafferanoOn); pill(s, "Proposta del formatore", 4.9, 5.45, 2.3, HEX.fondo2, HEX.petrolio, 12);
const A = ASP.etica;
card(s, 7.6, 1.5, 5.13, 4.4, { fill: A.soft, noLine: true });
icon(s, "etica", 7.9, 1.8, 0.6, "cerchio");
T(s, "4.2.2 · Applicare", { x: 8.65, y: 1.8, w: 3.8, h: 0.3, fontSize: 13, bold: true, color: A.fill, fontFace: "Outfit" });
T(s, "Scheda blocco", { x: 8.65, y: 2.1, w: 3.8, h: 0.45, fontSize: 20, bold: true, color: HEX.petrolio, fontFace: "Outfit" });
T(s, "Fondo nella tinta chiara dell'aspetto, icona in cerchio, codice e livello nel colore dell'aspetto, titolo in petrolio. Nessun bordo laterale colorato.", { x: 7.9, y: 2.85, w: 4.55, h: 2.2, fontSize: 14 });
livello(s, 2, 7.9, 5.25, 0.36);
fonte(s, "Palette originale del ProfTecnologIA Framework, non istituzionale UNESCO.", 6.45);

s = pres.addSlide({ masterName: "UNESCO Citazione" });
s.addText("«Testo della citazione, riportato fedelmente dalla traduzione italiana non ufficiale.»", { placeholder: "citazione" });
s.addText("– AI CFS, sezione o blocco", { placeholder: "autore" });

s = pres.addSlide({ masterName: "UNESCO Chiusura" });
s.addText("Grazie", { placeholder: "title" }); s.addText([{ text: "Nome Cognome", options: { bold: true, breakLine: true } }, { text: "contatti" }], { placeholder: "body" });
s.addText([...FONTI.map((f) => ({ text: f, options: { breakLine: true } })), { text: LICENZA, options: { breakLine: true } }, { text: CLAUSOLA }], { placeholder: "licenza" });

(async () => { await pres.writeFile({ fileName: OUT }); await applyTheme(OUT, K.THEME); console.log("ok", OUT); })();
