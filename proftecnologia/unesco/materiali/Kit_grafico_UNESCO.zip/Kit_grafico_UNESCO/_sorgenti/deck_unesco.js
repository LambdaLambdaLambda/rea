// Presentazione completa su un quadro UNESCO 2024 (studenti o docenti), costruita con il kit.
// I testi sono letti da unesco_it.json (traduzione italiana non ufficiale del ProfTecnologIA Framework): nessun contenuto inventato.
// uso: node deck_unesco.js studenti|docenti uscita.pptx [testo_slide.md]
const fs = require("fs");
const { applyTheme } = require(process.env.APPLY_THEME || "/root/.claude/skills/synced/c3460612-16fc-48c3-b005-f4c44099b8ff_a22df8e7-4c19-4401-b3d1-06128ef1142c/pptx/scripts/apply_theme.js");
const { makeKit } = require("./kit_pptx.js");
const { ATTR, FONTI, CLAUSOLA, LICENZA, ORDINE, LIVELLI, codice } = require("./palette.js");
const DATA = require("./unesco_it.json");
const Q = process.argv[2] || "studenti";
const OUT = process.argv[3] || `UNESCO_IA_${Q === "studenti" ? "Studenti" : "Docenti"}.pptx`;
const MDOUT = process.argv[4];
const D = DATA[Q], M = D.meta, B = D.blocchi;
const SIGLA = Q === "studenti" ? "AI CFS" : "AI CFT";
const NOME = Q === "studenti" ? "Il quadro UNESCO delle competenze sull'IA per gli studenti" : "Il quadro UNESCO delle competenze sull'IA per i docenti";
const K = makeKit({ title: NOME, author: "Antonio Scaramuzzino", attr: ATTR });
const { pres, T, numSq, pill, card, icon, livello, fonte, img, HEX, ASP, DIMS } = K;
const HEAD = "Outfit";
const prima = (t) => t.trim().split(/(?<=[.;])\s+(?=[A-ZÈ'])/)[0];
const descr = (b) => Array.isArray(b.descrizione) ? b.descrizione.join(" ") : b.descrizione;
const ASPETTI = M.aspetti.map((a) => a.id); // ordine del quadro
const md = [`# ${NOME} – testo delle slide`, ""];
let n = 0;
const add = (master, sec) => { n++; md.push("---", "", `## Slide ${n}`); return pres.addSlide({ masterName: master, sectionTitle: sec }); };
const log = (...t) => md.push(...t.flat().filter((x) => x !== undefined && x !== ""));
const note = (s, t) => { s.addNotes(t); md.push("", "### Note:", t); };

// 1 Copertina
pres.addSection({ title: "Apertura" });
let s = add("UNESCO Copertina", "Apertura");
const sottotitolo = `${SIGLA} (UNESCO, 2024) · traduzione italiana non ufficiale · percorso di formazione per docenti`;
s.addText(NOME, { placeholder: "title" });
s.addText(sottotitolo, { placeholder: "sottotitolo" });
s.addText([{ text: "Antonio Scaramuzzino", options: { bold: true, breakLine: true } }, { text: "Formatore · Alfabetizzazione all'IA" }], { placeholder: "autore" });
log(NOME, sottotitolo, "Antonio Scaramuzzino", "Formatore · Alfabetizzazione all'IA");
note(s, `Fonte dei contenuti: ${FONTI[Q === "studenti" ? 0 : 1]}. Traduzione italiana non ufficiale del ProfTecnologIA Framework.`);

// 2 Sezione
pres.addSection({ title: "Il quadro in sintesi" });
s = add("UNESCO Sezione Petrolio", "Il quadro in sintesi");
s.addText("01", { placeholder: "numero" }); s.addText("Il quadro in sintesi", { placeholder: "title" });
s.addText("Principi, livelli di progressione e aspetti di competenza", { placeholder: "sottotitolo" });
log("01", "Il quadro in sintesi", "Principi, livelli di progressione e aspetti di competenza");

// 3 Che cos'è
s = add("UNESCO Definizione", "Il quadro in sintesi");
s.addText("Che cos'è il quadro", { placeholder: "title" });
s.addText(M.presentazione, { placeholder: "body", fontSize: Q === "studenti" ? 16 : 15 });
s.addText("In cifre", { placeholder: "def_titolo" });
const nAsp = M.aspetti.length, nBl = Object.keys(B).length;
[[nAsp, "aspetti di competenza"], [3, "livelli di progressione"], [nBl, "blocchi di competenza"], [M.principi.length, "principi chiave"]].forEach(([v, l], i) => {
  T(s, String(v), { x: 7.45, y: 1.5 + i * 1.05, w: 1.3, h: 0.9, fontSize: 54, bold: true, color: i === 2 ? HEX.zafferano : HEX.petrolio, fontFace: HEAD, valign: "middle" });
  T(s, l, { x: 8.85, y: 1.5 + i * 1.05, w: 3.9, h: 0.9, fontSize: 18, bold: true, valign: "middle" });
});
s.addText(`${SIGLA}, presentazione del quadro`, { placeholder: "fonte" });
log("Che cos'è il quadro", M.presentazione, "In cifre", `${nAsp} aspetti di competenza · 3 livelli di progressione · ${nBl} blocchi di competenza · ${M.principi.length} principi chiave`, `${SIGLA}, presentazione del quadro`);

// 4 Principi
s = add("UNESCO Solo titolo", "Il quadro in sintesi");
s.addText(`${M.principi.length} principi chiave`, { placeholder: "title" });
log(`${M.principi.length} principi chiave`);
const np = M.principi.length, prh = (4.95 - (np - 1) * 0.08) / np;
M.principi.forEach((p, i) => {
  const y = 1.45 + i * (prh + 0.08);
  card(s, 0.6, y, 12.13, prh, { fill: i % 2 ? "FFFFFF" : HEX.fondo, line: HEX.fondo2 });
  numSq(s, i + 1, 0.8, y + (prh - 0.42) / 2, 0.42, HEX.petrolio);
  T(s, p.titolo, { x: 1.4, y, w: 3.7, h: prh, fontSize: 15, bold: true, color: HEX.petrolio, fontFace: HEAD, valign: "middle" });
  T(s, prima(p.testo), { x: 5.25, y, w: 7.3, h: prh, fontSize: 14, valign: "middle" });
  log(`${i + 1}. ${p.titolo} – ${prima(p.testo)}`);
});
fonte(s, `${SIGLA}, principi chiave: prima frase di ciascun principio`, 6.55); log(`${SIGLA}, principi chiave: prima frase di ciascun principio`);

// 5 Livelli
s = add("UNESCO Solo titolo", "Il quadro in sintesi");
s.addText("Tre livelli di progressione", { placeholder: "title" });
log("Tre livelli di progressione");
M.livelli.forEach((l, i) => {
  const x = 0.6 + i * 4.1;
  card(s, x, 1.5, 3.93, 4.85, { fill: i === 2 ? HEX.zafferanoChiaro : HEX.fondo, noLine: true });
  livello(s, i + 1, x + 0.3, 1.8, 0.55);
  T(s, l.id, { x: x + 0.3, y: 2.5, w: 3.4, h: 0.55, fontSize: 24, bold: true, color: HEX.petrolio, fontFace: HEAD });
  T(s, l.en, { x: x + 0.3, y: 3.02, w: 3.4, h: 0.32, fontSize: 14, italic: true, color: HEX.grigio });
  T(s, prima(l.testo), { x: x + 0.3, y: 3.5, w: 3.35, h: 2.7, fontSize: 15, valign: "top" });
  log(`${l.id} (${l.en}) – ${prima(l.testo)}`);
});
fonte(s, `${SIGLA}, livelli di progressione: prima frase della descrizione`, 6.55); log(`${SIGLA}, livelli di progressione: prima frase della descrizione`);

// 6 Aspetti
s = add("UNESCO Solo titolo", "Il quadro in sintesi");
s.addText(`${nAsp} aspetti di competenza`, { placeholder: "title" });
log(`${nAsp} aspetti di competenza`);
LIVELLI[Q].forEach((l, j) => { const x = 5.55 + j * 2.4; livello(s, j + 1, x, 1.45, 0.3); T(s, l, { x: x + 0.55, y: 1.42, w: 1.8, h: 0.36, fontSize: 14, bold: true, color: HEX.petrolio, fontFace: HEAD, valign: "middle" }); });
const rh = (6.4 - 1.95 - (nAsp - 1) * 0.08) / nAsp;
M.aspetti.forEach((a, i) => {
  const y = 1.95 + i * (rh + 0.08), A = ASP[a.id], ic = Math.min(0.62, rh - 0.16);
  card(s, 0.6, y, 12.13, rh, { fill: A.soft, noLine: true });
  icon(s, a.id, 0.78, y + (rh - ic) / 2, ic, "cerchio");
  T(s, a.nome, { x: 1.55, y: y + 0.06, w: 3.85, h: rh * 0.6, fontSize: 16, bold: true, color: A.fill, fontFace: HEAD, valign: "bottom" });
  T(s, a.en, { x: 1.55, y: y + rh * 0.62, w: 3.85, h: 0.28, fontSize: 12, italic: true, color: HEX.grigio });
  const tit = [0, 1, 2].map((j) => B[codice(Q, i, j)].titolo);
  tit.forEach((t, j) => T(s, t, { x: 5.55 + j * 2.4, y, w: 2.25, h: rh, fontSize: 14, bold: true, valign: "middle" }));
  log(`${a.nome} (${a.en}): ${tit.join(" · ")}`);
});
fonte(s, `${SIGLA}, aspetti e blocchi di competenza per livello`, 6.55);

// 7 Matrice
s = add("UNESCO Solo titolo", "Il quadro in sintesi");
s.addText(`La matrice: ${nAsp} aspetti × 3 livelli = ${nBl} blocchi`, { placeholder: "title" });
const mk = "matrice_" + Q, [mw, mh] = DIMS[mk], hh = 5.0, ww = hh * mw / mh;
img(s, mk + ".png", (13.333 - ww) / 2, 1.45, ww, hh);
fonte(s, `Rielaborazione grafica della matrice dell'${SIGLA}; codici dei blocchi come nell'originale`, 6.55);
log(`La matrice: ${nAsp} aspetti × 3 livelli = ${nBl} blocchi`, "[Figura: matrice aspetti × livelli]");

// Sezione 02 + una slide per aspetto
pres.addSection({ title: "Aspetti e blocchi" });
s = add("UNESCO Sezione Petrolio", "Aspetti e blocchi");
s.addText("02", { placeholder: "numero" }); s.addText("Aspetti e blocchi di competenza", { placeholder: "title" });
s.addText("Che cosa si chiede, aspetto per aspetto, a ogni livello", { placeholder: "sottotitolo" });
log("02", "Aspetti e blocchi di competenza", "Che cosa si chiede, aspetto per aspetto, a ogni livello");
M.aspetti.forEach((a, i) => {
  const A = ASP[a.id];
  s = add("UNESCO Solo titolo", "Aspetti e blocchi");
  s.addText(a.nome, { placeholder: "title" });
  icon(s, a.id, 12.03, 0.55, 0.7, "cerchio");
  const intro = prima(a.testo);
  T(s, intro, { x: 0.6, y: 1.38, w: 12.13, h: 0.78, fontSize: 13, italic: true, color: HEX.grigio, valign: "top" });
  log(a.nome, intro);
  [0, 1, 2].forEach((j) => {
    const id = codice(Q, i, j), b = B[id], x = 0.6 + j * 4.1;
    card(s, x, 2.25, 3.93, 4.22, { fill: A.soft, noLine: true });
    livello(s, j + 1, x + 0.28, 2.43, 0.34);
    T(s, `${id} · ${LIVELLI[Q][j]}`, { x: x + 0.9, y: 2.43, w: 2.8, h: 0.34, fontSize: 14, bold: true, color: A.fill, fontFace: HEAD, valign: "middle" });
    T(s, b.titolo, { x: x + 0.28, y: 2.85, w: 3.45, h: 0.82, fontSize: 16, bold: true, color: HEX.petrolio, fontFace: HEAD, valign: "top" });
    T(s, prima(descr(b)), { x: x + 0.28, y: 3.7, w: 3.45, h: 2.7, fontSize: 14, valign: "top" });
    log(`${id} ${b.titolo} (${LIVELLI[Q][j]}) – ${prima(descr(b))}`);
  });
  fonte(s, `${SIGLA}, aspetto «${a.nome}»: prima frase dell'aspetto e della descrizione di ciascun blocco`, 6.55);
});

// Sezione 03: dentro un blocco
pres.addSection({ title: "Dentro un blocco" });
s = add("UNESCO Sezione Petrolio", "Dentro un blocco");
s.addText("03", { placeholder: "numero" }); s.addText("Dentro un blocco di competenza", { placeholder: "title" });
const EX = Q === "studenti" ? "4.1.1" : "1.1", eb = B[EX], EA = ASP.mentalita;
const parti = Q === "studenti" ? "descrizione, obiettivi curricolari, metodi pedagogici, ambienti di apprendimento" : "descrizione, obiettivi curricolari, risultati di apprendimento, attività";
s.addText(`L'esempio del blocco ${EX}: ${parti}`, { placeholder: "sottotitolo" });
log("03", "Dentro un blocco di competenza", `L'esempio del blocco ${EX}: ${parti}`);

const grid4 = (s, items, getId, getTit, getTxt, y0) => {
  const wgt = [0, 1].map((r) => Math.max(...items.slice(r * 2, r * 2 + 2).map((it) => getTxt(it).length + (getTit(it) || "").length)) + 180);
  const tot = 6.45 - y0 - 0.12, hs = wgt.map((w) => tot * w / (wgt[0] + wgt[1]));
  items.forEach((it, k) => {
    const r = Math.floor(k / 2), h = hs[r], x = 0.6 + (k % 2) * 6.17, y = y0 + (r ? hs[0] + 0.12 : 0);
    card(s, x, y, 5.96, h, { fill: k % 3 === 0 ? EA.soft : HEX.fondo, noLine: true });
    let ty = y + 0.18;
    const lab = getId(it, k);
    if (lab) { T(s, lab, { x: x + 0.25, y: ty, w: 5.5, h: 0.32, fontSize: 14, bold: true, color: EA.fill, fontFace: HEAD }); ty += 0.36; }
    const tt = getTit(it);
    if (tt) { const two = tt.length > 52; T(s, tt, { x: x + 0.25, y: ty, w: 5.5, h: two ? 0.6 : 0.34, fontSize: 15, bold: true, color: HEX.petrolio, fontFace: HEAD, valign: "top" }); ty += two ? 0.64 : 0.4; }
    T(s, getTxt(it), { x: x + 0.25, y: ty, w: 5.5, h: y + h - ty - 0.1, fontSize: 14, valign: "top" });
    log(`- ${[lab, tt, getTxt(it)].filter(Boolean).join(" – ")}`);
  });
};
if (Q === "studenti") {
  s = add("UNESCO Definizione", "Dentro un blocco");
  s.addText(`${EX} · ${eb.titolo}`, { placeholder: "title" });
  s.addText(descr(eb), { placeholder: "body" });
  s.addText("Obiettivi curricolari", { placeholder: "def_titolo" });
  eb.obiettivi.forEach((o, k) => {
    numSq(s, k + 1, 7.45, 1.55 + k * 1.3, 0.46, EA.fill);
    T(s, o.id, { x: 8.1, y: 1.5 + k * 1.3, w: 4.6, h: 0.3, fontSize: 13, bold: true, color: EA.fill, fontFace: HEAD });
    T(s, o.titolo, { x: 8.1, y: 1.82 + k * 1.3, w: 4.7, h: 0.9, fontSize: 15, bold: true, valign: "top" });
  });
  s.addText(`${SIGLA}, blocco ${EX}: descrizione e titoli degli obiettivi curricolari`, { placeholder: "fonte" });
  log(`${EX} · ${eb.titolo}`, descr(eb), "Obiettivi curricolari", eb.obiettivi.map((o, k) => `${k + 1}. ${o.id} ${o.titolo}`));
  note(s, "I testi completi degli obiettivi curricolari sono nella dispensa e nella sezione UNESCO del ProfTecnologIA Framework.");

  s = add("UNESCO Solo titolo", "Dentro un blocco");
  s.addText(`${EX} · Metodi e ambienti di apprendimento`, { placeholder: "title" });
  log(`${EX} · Metodi e ambienti di apprendimento`, "Metodi pedagogici suggeriti");
  T(s, "Metodi pedagogici suggeriti", { x: 0.6, y: 1.45, w: 6.9, h: 0.4, fontSize: 18, bold: true, color: HEX.petrolio, fontFace: HEAD });
  eb.metodi.forEach((m, k) => {
    const y = 2.0 + k * 1.1;
    numSq(s, k + 1, 0.6, y, 0.46, HEX.petrolio);
    T(s, m.titolo, { x: 1.25, y: y - 0.04, w: 6.3, h: 0.95, fontSize: 15, valign: "top" });
    log(`${k + 1}. ${m.titolo}`);
  });
  card(s, 7.9, 1.45, 4.83, 4.95, { fill: HEX.zafferanoChiaro, noLine: true });
  T(s, "Ambienti di apprendimento", { x: 8.2, y: 1.65, w: 4.3, h: 0.4, fontSize: 18, bold: true, color: HEX.petrolio, fontFace: HEAD });
  T(s, eb.ambienti.map((a, k) => ({ text: a, options: { bullet: true, breakLine: k < eb.ambienti.length - 1 } })), { x: 8.2, y: 2.2, w: 4.3, h: 4.0, fontSize: 14, valign: "top", paraSpaceAfter: 8 });
  log("Ambienti di apprendimento", eb.ambienti.map((a) => `- ${a}`));
  fonte(s, `${SIGLA}, blocco ${EX}: titoli dei metodi pedagogici e ambienti di apprendimento`, 6.55);
} else {
  s = add("UNESCO Solo titolo", "Dentro un blocco");
  s.addText(`${EX} · ${eb.titolo}: obiettivi curricolari`, { placeholder: "title" });
  T(s, descr(eb), { x: 0.6, y: 1.38, w: 12.13, h: 0.8, fontSize: 14, italic: true, color: HEX.grigio, valign: "top" });
  log(`${EX} · ${eb.titolo}: obiettivi curricolari`, descr(eb));
  grid4(s, eb.obiettivi, (o) => o.id, () => "", (o) => o.testo, 2.25);
  fonte(s, `${SIGLA}, blocco ${EX}: descrizione e obiettivi curricolari`, 6.58);
  s = add("UNESCO Solo titolo", "Dentro un blocco");
  s.addText(`${EX} · Risultati di apprendimento`, { placeholder: "title" });
  log(`${EX} · Risultati di apprendimento`);
  grid4(s, eb.risultati, (o) => o.id, () => "", (o) => o.testo, 1.5);
  fonte(s, `${SIGLA}, blocco ${EX}: risultati di apprendimento attesi`, 6.55);
  s = add("UNESCO Solo titolo", "Dentro un blocco");
  s.addText(`${EX} · Attività suggerite`, { placeholder: "title" });
  log(`${EX} · Attività suggerite`);
  grid4(s, eb.attivita, (o, k) => "Attività " + (k + 1), (o) => o.titolo, (o) => o.testo, 1.5);
  fonte(s, `${SIGLA}, blocco ${EX}: attività suggerite`, 6.55);
}

// Proposta di lavoro (dichiarata come proposta del formatore)
s = add("UNESCO Box", "Dentro un blocco");
s.addText("Dal quadro alla progettazione", { placeholder: "title" });
s.addText("Proposta di lavoro per il corso", { placeholder: "box_titolo" });
const passi = Q === "studenti" ? [
  "Scegliete un aspetto e individuate il livello (Comprendere, Applicare, Creare) adatto alla vostra classe.",
  "Leggete la descrizione e gli obiettivi curricolari del blocco corrispondente.",
  "Scegliete uno dei metodi pedagogici suggeriti e adattatelo alla vostra disciplina e all'età degli studenti.",
  "Verificate quali ambienti di apprendimento avete a disposizione (anche unplugged).",
  "Condividete la bozza di attività nel gruppo e confrontatela con il blocco di partenza.",
] : [
  "Collocatevi nella matrice: per ciascun aspetto, in quale livello (Acquisire, Approfondire, Creare) vi riconoscete?",
  "Scegliete un blocco da sviluppare e leggetene descrizione e risultati di apprendimento.",
  "Selezionate un'attività suggerita e definite come realizzarla nel vostro contesto scolastico.",
  "Individuate le evidenze che mostreranno il raggiungimento dei risultati di apprendimento.",
  "Condividete il piano nel gruppo e ripetete l'autovalutazione a fine percorso.",
];
s.addText(passi.map((p, k) => ({ text: `${k + 1}.  ${p}`, options: { breakLine: k < passi.length - 1 } })), { placeholder: "body", paraSpaceAfter: 10 });
pill(s, "Proposta del formatore", 10.2, 1.85, 2.3, HEX.petrolio, "FFFFFF", 12);
log("Dal quadro alla progettazione", "Proposta di lavoro per il corso [Proposta del formatore, non contenuto UNESCO]", passi.map((p, k) => `${k + 1}. ${p}`));
note(s, "Questa sequenza è una proposta del formatore per l'uso del quadro nel corso: non fa parte del testo UNESCO.");

// Citazione
s = add("UNESCO Citazione", "Dentro un blocco");
const cit = Q === "studenti"
  ? "«[Il quadro] specifica gli elementi essenziali che gli studenti devono costruire e aggiornare continuamente per diventare utenti responsabili e co-creatori attivi dell'IA, nonché potenziali protagonisti nella definizione e nello sviluppo delle prossime generazioni di IA.»"
  : "«Il quadro riconosce che lo sviluppo delle competenze è un processo complesso e dipendente dal contesto, né gerarchico né lineare, e si propone come percorso di riferimento anziché come sequenza rigida di passaggi obbligati.»";
if (Q === "studenti" && !M.presentazione.includes("specifica gli elementi essenziali che gli studenti devono costruire e aggiornare continuamente per diventare utenti responsabili e co-creatori attivi dell'IA, nonché potenziali protagonisti nella definizione e nello sviluppo delle prossime generazioni di IA")) throw new Error("citazione non trovata");
if (Q === "docenti" && !M.presentazione.includes(cit.slice(1, -2))) throw new Error("citazione non trovata");
s.addText(cit, { placeholder: "citazione" });
s.addText(`– ${SIGLA}, presentazione del quadro (trad. it. non ufficiale)`, { placeholder: "autore" });
log(cit, `– ${SIGLA}, presentazione del quadro (trad. it. non ufficiale)`);

// Chiusura
pres.addSection({ title: "Chiusura" });
s = add("UNESCO Chiusura", "Chiusura");
s.addText("Grazie", { placeholder: "title" });
s.addText([{ text: "Antonio Scaramuzzino", options: { bold: true, breakLine: true } }, { text: "Quadri completi, obiettivi, metodi e autovalutazione: sezione UNESCO del ProfTecnologIA Framework", options: { breakLine: true } }, { text: "proftecnologia-framework.vercel.app/unesco/" }], { placeholder: "body" });
const lic = [FONTI[Q === "studenti" ? 0 : 1], LICENZA, CLAUSOLA, "This translation was not created by UNESCO and should not be considered an official UNESCO translation. UNESCO shall not be liable for any content or error in this translation."];
s.addText(lic.map((t, k) => ({ text: t, options: { breakLine: k < lic.length - 1 } })), { placeholder: "licenza", paraSpaceAfter: 6 });
log("Grazie", "Antonio Scaramuzzino", "proftecnologia-framework.vercel.app/unesco/", lic);

(async () => {
  await pres.writeFile({ fileName: OUT }); await applyTheme(OUT, K.THEME);
  if (MDOUT) fs.writeFileSync(MDOUT, md.join("\n").replace(/\n## /g, "\n\n## ") + "\n");
  console.log("ok", OUT, n, "slide");
})();
