// Kit grafico UNESCO IA (ProfTecnologIA Framework) — palette e dati condivisi
// Identità originale della sezione UNESCO del ProfTecnologIA Framework: non usa logo né elementi grafici istituzionali UNESCO.
const HEX = {
  petrolio: "0F3D5E", petrolioScuro: "0A2C44", zafferano: "F2B134", zafferanoOn: "1E1A10", acqua: "5CC8C2",
  testo: "14262F", grigio: "5B6C74", linea: "D3DEE2", fondo: "F3F6F7", fondo2: "EAF0F2", link: "0B6E8A", celeste: "8FD3E8",
  zafferanoChiaro: "FCEFD2", acquaChiara: "DDF4F2",
};
// Aspetti di competenza: colore pieno (testo bianco sopra) e tinta chiara (fondo card)
const ASP = {
  mentalita:     { nome: "Mentalità incentrata sull'essere umano", fill: "0E7C86", soft: "DDF3F3", icona: "mentalita" },
  etica:         { nome: "Etica dell'IA", fill: "A65A1A", soft: "F8E9DA", icona: "etica" },
  tecniche:      { nome: "Tecniche e applicazioni dell'IA", fill: "3D4DB7", soft: "E3E6F8", icona: "tecniche" },
  fondamenti:    { nome: "Fondamenti e applicazioni dell'IA", fill: "3D4DB7", soft: "E3E6F8", icona: "tecniche" },
  progettazione: { nome: "Progettazione di sistemi di IA", fill: "A12C6B", soft: "F6E0EC", icona: "progettazione" },
  pedagogia:     { nome: "Pedagogia dell'IA", fill: "2F7D32", soft: "E0F0E1", icona: "pedagogia" },
  sviluppo:      { nome: "IA per lo sviluppo professionale", fill: "6B4BB8", soft: "ECE5F8", icona: "sviluppo" },
};
const ORDINE = {
  studenti: ["mentalita", "etica", "tecniche", "progettazione"],
  docenti: ["mentalita", "etica", "fondamenti", "pedagogia", "sviluppo"],
};
const LIVELLI = { studenti: ["Comprendere", "Applicare", "Creare"], docenti: ["Acquisire", "Approfondire", "Creare"] };
// codice del blocco a partire da quadro, indice aspetto (0..), indice livello (0..2)
const codice = (quadro, a, l) => quadro === "studenti" ? `4.${l + 1}.${a + 1}` : `${a + 1}.${l + 1}`;
const ATTR = "Contenuti: UNESCO (2024), quadri di competenze sull'IA per studenti e docenti · trad. it. non ufficiale · CC BY-SA 3.0 IGO";
const FONTI = [
  "UNESCO (2024). AI competency framework for students. Paris, UNESCO. https://doi.org/10.54675/JKJB9835",
  "UNESCO (2024). AI competency framework for teachers. Paris, UNESCO. https://doi.org/10.54675/ZJTE2084",
];
const CLAUSOLA = "Questa traduzione non è stata realizzata dall'UNESCO e non deve essere considerata una traduzione ufficiale dell'UNESCO. L'UNESCO non è responsabile del contenuto né di eventuali errori di questa traduzione.";
const LICENZA = "Opere originali con licenza CC BY-SA 3.0 IGO. Traduzione e adattamento: Antonio Scaramuzzino, ProfTecnologIA Framework, distribuiti con la stessa licenza CC BY-SA 3.0 IGO. Nessun logo o elemento grafico istituzionale UNESCO è utilizzato.";
module.exports = { HEX, ASP, ORDINE, LIVELLI, codice, ATTR, FONTI, CLAUSOLA, LICENZA };
