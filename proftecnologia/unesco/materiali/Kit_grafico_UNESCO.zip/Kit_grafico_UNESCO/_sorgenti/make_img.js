// Genera le immagini PNG del kit in ../img a partire dalle icone SVG e dai dati (sharp)
// uso: node make_img.js
const fs = require("fs");
const path = require("path");
const sharp = require("sharp");
const { HEX, ASP, ORDINE, LIVELLI, codice } = require("./palette.js");
const ICONS = require("./icons.json");
const DATA = require("./unesco_it.json");
const IMG = path.resolve(__dirname, "../img") + "/";
const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/'/g, "&#39;");
const png = (svg, file, w) => sharp(Buffer.from(svg), { density: 300 }).resize({ width: w }).png().toFile(IMG + file);

const icon = (id, color) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48" color="#${color}">${ICONS[id]}</svg>`;
// cerchio pieno con icona bianca (motivo ricorrente "icona in cerchio")
const iconCircle = (id, fill) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64"><circle cx="32" cy="32" r="31" fill="#${fill}"/><g transform="translate(12 12) scale(0.8333)" color="#FFFFFF">${ICONS[id]}</g></svg>`;
const livelli = (n, off) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="60" height="40">${[0, 1, 2].map((i) => `<rect x="${i * 21}" y="${26 - i * 12}" width="16" height="${14 + i * 12}" rx="3" fill="#${i < n ? HEX.zafferano : off}"/>`).join("")}</svg>`;
const logo = fs.readFileSync(path.resolve(__dirname, "../img/svg/logo_unesco_ia.svg"), "utf8");
// archi decorativi derivati dal logo di sezione (copertine e chiusure)
const archi = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="40 360 720 420" width="720" height="420">
 <path d="M80 720a320 320 0 0 1 640 0" fill="none" stroke="#${HEX.zafferano}" stroke-width="64" stroke-linecap="round"/>
 <path d="M216 720a184 184 0 0 1 368 0" fill="none" stroke="#${HEX.acqua}" stroke-width="64" stroke-linecap="round"/>
 <circle cx="400" cy="720" r="44" fill="#FFFFFF"/></svg>`;
// simbolo per il piè di pagina: i sei colori degli aspetti come punti
const simbolo = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 132 20" width="132" height="20">${["mentalita", "etica", "tecniche", "progettazione", "pedagogia", "sviluppo"].map((k, i) => `<circle cx="${10 + i * 22}" cy="10" r="8" fill="#${ASP[k].fill}"/>`).join("")}</svg>`;

// a capo semplice per le celle della matrice
function wrap(text, max) { const out = []; let line = ""; text.split(" ").forEach((w) => { if ((line + " " + w).trim().length > max) { out.push(line.trim()); line = w; } else line += " " + w; }); if (line.trim()) out.push(line.trim()); return out; }
function matrice(quadro) {
  const asp = ORDINE[quadro], liv = LIVELLI[quadro], B = DATA[quadro].blocchi;
  const W = 2000, c0 = 520, cw = (W - c0) / 3, hh = 110, rh = 236, gap = 10;
  const H = hh + asp.length * (rh + gap);
  let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}"><rect width="${W}" height="${H}" fill="#FFFFFF"/>`;
  liv.forEach((l, j) => {
    const x = c0 + j * cw;
    s += `<rect x="${x + gap / 2}" y="0" width="${cw - gap}" height="${hh - gap}" rx="14" fill="#${HEX.petrolio}"/>`;
    s += `<g transform="translate(${x + 30} 26) scale(0.95)">${livelli(j + 1, "35607E").replace(/<\/?svg[^>]*>/g, "")}</g>`;
    s += `<text x="${x + 110}" y="68" font-family="Outfit" font-weight="700" font-size="44" fill="#FFFFFF">${esc(l)}</text>`;
  });
  asp.forEach((a, i) => {
    const y = hh + i * (rh + gap), A = ASP[a];
    s += `<rect x="0" y="${y}" width="${c0 - gap}" height="${rh}" rx="14" fill="#${A.fill}"/>`;
    s += `<g transform="translate(24 ${y + rh / 2 - 36}) scale(1.5)" color="#FFFFFF">${ICONS[A.icona]}</g>`;
    wrap(A.nome, 18).forEach((ln, k, arr) => { s += `<text x="112" y="${y + rh / 2 - (arr.length - 1) * 21 + k * 42 + 13}" font-family="Outfit" font-weight="700" font-size="36" fill="#FFFFFF">${esc(ln)}</text>`; });
    liv.forEach((l, j) => {
      const x = c0 + j * cw, id = codice(quadro, i, j), b = B[id];
      s += `<rect x="${x + gap / 2}" y="${y}" width="${cw - gap}" height="${rh}" rx="14" fill="#${A.soft}"/>`;
      s += `<text x="${x + 32}" y="${y + 56}" font-family="Outfit" font-weight="700" font-size="34" fill="#${A.fill}">${id}</text>`;
      wrap(b.titolo, 24).forEach((ln, k) => { s += `<text x="${x + 32}" y="${y + 108 + k * 44}" font-family="'Source Sans 3'" font-weight="700" font-size="38" fill="#${HEX.testo}">${esc(ln)}</text>`; });
    });
  });
  return s + "</svg>";
}

(async () => {
  const dims = {};
  const out = async (svg, name, w) => { const r = await png(svg, name + ".png", w); dims[name] = [r.width, r.height]; };
  await out(logo, "logo_unesco_ia", 600);
  for (const k of ["mentalita", "etica", "tecniche", "progettazione", "pedagogia", "sviluppo"]) {
    const a = ASP[k];
    await out(icon(k, a.fill), "icona_" + k, 256);
    await out(icon(k, "FFFFFF"), "icona_" + k + "_bianca", 256);
    await out(iconCircle(k, a.fill), "icona_" + k + "_cerchio", 256);
  }
  for (const n of [1, 2, 3]) await out(livelli(n, HEX.linea), "livello_" + n, 240);
  await out(archi, "archi", 1200);
  await out(simbolo, "simbolo_aspetti", 528);
  await out(matrice("studenti"), "matrice_studenti", 2000);
  await out(matrice("docenti"), "matrice_docenti", 2000);
  fs.writeFileSync(__dirname + "/dims.json", JSON.stringify(dims, null, 1));
  console.log(Object.keys(dims).length, "immagini");
})();
