// Genera il testo Markdown della dispensa sui quadri UNESCO a partire da unesco_it.json
// I testi del quadro sono riportati dalla traduzione; le parti di raccordo sono del curatore e le proposte sono dichiarate.
// uso: node gen_dispensa_md.js uscita.md
const fs = require("fs");
const D = require("./unesco_it.json");
const { ORDINE, LIVELLI, codice, FONTI, CLAUSOLA, LICENZA } = require("./palette.js");
const OUT = process.argv[2] || "UNESCO_IA_Dispensa.md";
const prima = (t) => t.trim().split(/(?<=[.;])\s+(?=[A-ZÈ'])/)[0];
const descr = (b) => Array.isArray(b.descrizione) ? b.descrizione.join(" ") : b.descrizione;
const cell = (t) => t.replace(/\|/g, "/");
const L = [];
const p = (...x) => L.push(...x, "");

p("# I quadri UNESCO delle competenze sull'IA – Studenti e docenti: struttura, blocchi di competenza e uso nella progettazione");
p("*Dispensa per i docenti in formazione · a cura di Antonio Scaramuzzino*");
p("I testi dei quadri sono tratti dalla traduzione italiana non ufficiale del ProfTecnologIA Framework. I riferimenti usano i codici dei blocchi di competenza (per esempio 4.1.1 per gli studenti, 1.1 per i docenti) come nelle pubblicazioni originali.");
p("**Obiettivi della dispensa**");
p("- Conoscere struttura e principi dei due quadri UNESCO del 2024 sulle competenze in materia di IA.",
  "- Leggere un blocco di competenza: descrizione, obiettivi, metodi, risultati e attività.",
  "- Usare i quadri per collocare le proprie competenze e per progettare attività con gli studenti.");
p("---");

// 01
p("## 01 · Due quadri, una stessa logica");
p("Nel 2024 l'UNESCO ha pubblicato due quadri di competenze sull'IA: uno per gli studenti (AI competency framework for students, AI CFS) e uno per i docenti (AI competency framework for teachers, AI CFT). Entrambi sono costruiti come una matrice a due dimensioni: gli **aspetti** di competenza e i **livelli** di progressione. Ogni incrocio tra un aspetto e un livello è un **blocco di competenza**.");
const S = D.studenti, T = D.docenti;
p("| Elemento | Studenti (AI CFS) | Docenti (AI CFT) |", "|---|---|---|",
  `| Aspetti | ${S.meta.aspetti.length}: ${S.meta.aspetti.map((a) => a.nome).join(", ")} | ${T.meta.aspetti.length}: ${T.meta.aspetti.map((a) => a.nome).join(", ")} |`,
  `| Livelli | ${LIVELLI.studenti.join(", ")} | ${LIVELLI.docenti.join(", ")} |`,
  `| Blocchi di competenza | ${Object.keys(S.blocchi).length} | ${Object.keys(T.blocchi).length} |`,
  `| Principi chiave | ${S.meta.principi.length} | ${T.meta.principi.length} |`,
  "| Contenuto di ogni blocco | Descrizione, obiettivi curricolari, metodi pedagogici, ambienti di apprendimento | Descrizione, obiettivi curricolari, risultati di apprendimento, attività suggerite |");
p("> **Attenzione alla traduzione**");
L.pop(); p("> - La traduzione è non ufficiale: per usi formali fare riferimento ai testi originali in inglese.", "> - Accanto ai titoli italiani di aspetti, livelli e blocchi si riporta, dove utile, il titolo inglese originale.");
p("---");

function quadro(num, Q, sigla, chi) {
  const X = D[Q], M = X.meta, B = X.blocchi;
  p(`## ${num} · Il quadro per ${chi} (${sigla})`);
  p(M.presentazione);
  p(`![Matrice degli aspetti e dei livelli dell'${sigla}: rielaborazione grafica; codici dei blocchi come nell'originale](matrice_${Q})`);
  p("### Principi chiave");
  p(`L'${sigla} si fonda su ${M.principi.length} principi. Di ciascuno si riporta il titolo e la prima frase.`);
  M.principi.forEach((x, i) => L.push(`${i + 1}. **${x.titolo}.** ${prima(x.testo)}`)); L.push("");
  p("### Livelli di progressione");
  p("| Livello | Descrizione (prima frase) |", "|---|---|", ...M.livelli.map((l) => `| ${l.id} | *${l.en}.* ${cell(prima(l.testo))} |`));
  p("### Aspetti di competenza");
  M.aspetti.forEach((a) => { p(`#### ${a.nome} (${a.en})`); p(a.testo); });
  p(`### I ${Object.keys(B).length} blocchi di competenza`);
  const rows = [];
  M.aspetti.forEach((a, i) => [0, 1, 2].forEach((j) => { const id = codice(Q, i, j), b = B[id]; rows.push(`| ${id} | **${cell(b.titolo)}** · ${LIVELLI[Q][j]} | ${cell(prima(descr(b)))} |`); }));
  p("| Codice | Blocco e livello | Descrizione (prima frase) |", "|---|---|---|", ...rows);
  p("---");
}
quadro("02", "studenti", "AI CFS", "gli studenti");
quadro("03", "docenti", "AI CFT", "i docenti");

// 04 esempi
p("## 04 · Dentro un blocco di competenza");
p("Per usare i quadri nella progettazione conviene leggere un blocco nella sua interezza. Si riportano due esempi relativi allo stesso tema, l'agentività umana: il blocco 4.1.1 del quadro per gli studenti e il blocco 1.1 del quadro per i docenti.");
const b1 = S.blocchi["4.1.1"];
p(`### Studenti · 4.1.1 ${b1.titolo} (${b1.titolo_en})`);
p(descr(b1));
p("#### Obiettivi curricolari");
b1.obiettivi.forEach((o) => p(`**${o.id} – ${o.titolo}.** ${o.testo}`));
p("#### Metodi pedagogici suggeriti");
b1.metodi.forEach((m, i) => p(`**${i + 1}. ${m.titolo}.** ${m.testo}`));
p("> **Ambienti di apprendimento** (blocco 4.1.1)", ...b1.ambienti.map((a) => `> - ${a}`));
const b2 = T.blocchi["1.1"];
p(`### Docenti · 1.1 ${b2.titolo} (${b2.titolo_en})`);
p(b2.descrizione);
p("#### Obiettivi curricolari");
b2.obiettivi.forEach((o) => p(`**${o.id}.** ${o.testo}`));
p("#### Risultati di apprendimento");
p("| Codice | Risultato di apprendimento |", "|---|---|", ...b2.risultati.map((r) => `| ${r.id} | ${cell(r.testo)} |`));
p("#### Attività suggerite");
b2.attivita.forEach((a, i) => p(`**${i + 1}. ${a.titolo}.** ${a.testo}`));
p("> **Attività per il corso** (proposta del formatore, non contenuto UNESCO)",
  "> 1. Ciascun docente si colloca nella matrice dell'AI CFT: per ogni aspetto indica il livello in cui si riconosce (Acquisire, Approfondire, Creare).",
  "> 2. In piccoli gruppi si sceglie un blocco dell'AI CFS adatto alla propria classe e se ne leggono descrizione e obiettivi curricolari.",
  "> 3. Si seleziona uno dei metodi pedagogici suggeriti e lo si adatta alla propria disciplina e all'età degli studenti.",
  "> 4. Si verificano gli ambienti di apprendimento disponibili, anche senza dispositivi.",
  "> 5. Si presenta la bozza al gruppo e si indica a quale blocco dell'AI CFT corrisponde la competenza del docente richiesta per realizzarla.");
p("---");

p("## Fonti e licenza");
FONTI.forEach((f) => L.push(`- ${f}`)); L.push("- Traduzione italiana non ufficiale: ProfTecnologIA Framework, sezione UNESCO (proftecnologia-framework.vercel.app/unesco/).", "");
p(LICENZA);
p(CLAUSOLA);
p("*This translation was not created by UNESCO and should not be considered an official UNESCO translation. UNESCO shall not be liable for any content or error in this translation.*");
fs.writeFileSync(OUT, L.join("\n"));
console.log("ok", OUT, L.length, "righe");
