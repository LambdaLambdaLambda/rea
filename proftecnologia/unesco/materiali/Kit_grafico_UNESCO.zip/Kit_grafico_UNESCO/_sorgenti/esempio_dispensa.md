# Titolo della dispensa – Sottotitolo · destinatari del percorso

*A cura di: Nome Cognome · Ente · gg mese aaaa*

Testo introduttivo in Source Sans 3, 10,5 pt giustificato. I riferimenti ai quadri UNESCO usano i codici dei blocchi di competenza (es. 4.1.1 per gli studenti, 1.1 per i docenti).

**Obiettivi della dispensa**

- Primo obiettivo.
- Secondo obiettivo.

---

## 01 · Titolo del capitolo

Testo del capitolo. L'apertura usa la linguetta petrolio con il numero in zafferano e, sotto il titolo, il simbolo dei sei colori degli aspetti.

### Titolo di paragrafo

![Figura: matrice aspetti × livelli del quadro per gli studenti · rielaborazione grafica](matrice_studenti)

#### Titolo di terzo livello

> **Approfondimento** (fondo grigio-azzurro)
> - Primo punto.
> - Secondo punto.

> «Citazione fedele dalla traduzione.» (AI CFS, blocco 4.1.1)

Elenco numerato con quadrati petrolio:

1. **Primo elemento.** Testo di accompagnamento.
2. **Secondo elemento.** Testo di accompagnamento.

| Aspetto | Comprendere | Applicare | Creare |
|---|---|---|---|
| Mentalità incentrata sull'essere umano | 4.1.1 Agentività umana | 4.2.1 Responsabilità umana | 4.3.1 Cittadinanza nell'era dell'IA |
| Etica dell'IA | 4.1.2 Etica interiorizzata | 4.2.2 Uso sicuro e responsabile | 4.3.2 Etica fin dalla progettazione |

| Codice | Blocco | Descrizione |
|---|---|---|
| 1.1 | **Agentività umana** · Acquisire | La prima colonna prende il colore dell'aspetto ricavato dal codice. |
| 2.2 | **Uso sicuro e responsabile** · Approfondire | Codici dei docenti: aspetto.livello. |

> **Attenzione** (fondo acqua chiaro: avvertenze, definizioni)
> Testo dell'avvertenza.

> **Attività per la classe** (durata · livello · proposta del formatore)
> 1. Primo passo.
> 2. Secondo passo.

---

## Fonti e licenza

- UNESCO (2024). AI competency framework for students. Paris, UNESCO. https://doi.org/10.54675/JKJB9835
- UNESCO (2024). AI competency framework for teachers. Paris, UNESCO. https://doi.org/10.54675/ZJTE2084

Opere originali con licenza CC BY-SA 3.0 IGO. Traduzione e adattamento distribuiti con la stessa licenza CC BY-SA 3.0 IGO.

Questa traduzione non è stata realizzata dall'UNESCO e non deve essere considerata una traduzione ufficiale dell'UNESCO. L'UNESCO non è responsabile del contenuto né di eventuali errori di questa traduzione.
