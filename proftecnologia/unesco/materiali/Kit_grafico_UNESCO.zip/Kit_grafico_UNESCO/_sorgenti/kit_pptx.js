// Kit grafico UNESCO IA — layout e componenti PowerPoint (pptxgenjs)
// Identità originale della sezione UNESCO del ProfTecnologIA Framework: petrolio dominante, zafferano per accenti e livelli,
// un colore per ciascun aspetto di competenza. Nessun logo né elemento grafico istituzionale UNESCO.
const pptxgen = require("pptxgenjs");
const path = require("path");
const { HEX, ASP } = require("./palette.js");
const KIT = path.resolve(__dirname, "..");
const IMG = KIT + "/img/";
const DIMS = require("./dims.json");

const THEME = {
  name: "UNESCO IA", headFontFace: "Outfit", bodyFontFace: "Source Sans 3",
  colors: { dk1: HEX.testo, lt1: "FFFFFF", dk2: HEX.petrolio, lt2: HEX.fondo, accent1: HEX.petrolio, accent2: HEX.zafferano, accent3: HEX.acqua, accent4: ASP.mentalita.fill, accent5: ASP.etica.fill, accent6: ASP.tecniche.fill, hlink: HEX.link, folHlink: ASP.sviluppo.fill },
};
const HEAD = "Outfit", BODY = "Source Sans 3";
const W = 13.333, H = 7.5;
const ASPETTI_LAYOUT = ["mentalita", "etica", "tecniche", "progettazione", "pedagogia", "sviluppo"];

function makeKit(opts) {
  const pres = new pptxgen();
  pres.layout = "LAYOUT_WIDE";
  pres.theme = { headFontFace: HEAD, bodyFontFace: BODY };
  pres.title = opts.title; pres.author = opts.author || "";
  const ATTR = opts.attr;
  const imgH = (file, x, y, h) => ({ image: { path: IMG + file + ".png", x, y, h, w: h * DIMS[file][0] / DIMS[file][1] } });
  const dots = (x, y) => imgH("simbolo_aspetti", x, y, 0.13);
  const footer = (dark) => [
    { text: { text: ATTR, options: { x: 0.6, y: 7.02, w: 10.6, h: 0.3, fontSize: 9, italic: true, color: dark ? HEX.celeste : HEX.grigio, fontFace: BODY, margin: 0 } } },
    imgH("logo_unesco_ia", 11.55, 6.99, 0.34),
  ];
  const slideNum = { x: 12.1, y: 7.02, w: 0.63, h: 0.3, fontSize: 11, bold: true, color: HEX.petrolio, align: "right", fontFace: HEAD, margin: 0 };
  const ph = (name, type, o) => ({ placeholder: { options: { name, type, ...o }, text: o.prompt || "" } });
  const TITLE = { x: 0.6, y: 0.5, w: 12.13, h: 0.8, fontSize: 32, bold: true, color: HEX.petrolio, fontFace: HEAD, align: "left", valign: "middle", margin: 0, prompt: "Titolo della slide" };

  pres.defineSlideMaster({ title: "UNESCO Copertina", background: { color: HEX.petrolio },
    objects: [
      imgH("archi", 8.55, 3.55, 3.2),
      imgH("logo_unesco_ia", 0.8, 0.7, 0.7),
      ph("title", "title", { x: 0.8, y: 1.6, w: 8.6, h: 2.2, fontSize: 44, bold: true, color: "FFFFFF", fontFace: HEAD, align: "left", valign: "bottom", margin: 0, prompt: "Titolo del percorso" }),
      ph("sottotitolo", "body", { x: 0.8, y: 3.95, w: 8.0, h: 1.0, fontSize: 20, color: HEX.celeste, fontFace: BODY, align: "left", valign: "top", margin: 0, prompt: "Sottotitolo / destinatari" }),
      ph("autore", "body", { x: 0.8, y: 5.35, w: 7.4, h: 1.2, fontSize: 16, color: "FFFFFF", fontFace: BODY, align: "left", valign: "top", margin: 0, prompt: "Formatore · Ente · Data" }),
      ...footer(true)] });

  const sezione = (nome, panel, numColor, extra = []) => pres.defineSlideMaster({ title: "UNESCO Sezione " + nome, background: { color: "FFFFFF" },
    objects: [{ rect: { x: 0, y: 0, w: 4.1, h: 6.85, fill: { color: panel } } }, ...extra,
      ph("numero", "body", { x: 0.6, y: 2.4, w: 3.0, h: 2.0, fontSize: 110, bold: true, color: numColor, fontFace: HEAD, align: "left", valign: "middle", margin: 0, prompt: "01" }),
      ph("title", "title", { x: 4.8, y: 2.2, w: 7.9, h: 1.5, fontSize: 40, bold: true, color: HEX.petrolio, fontFace: HEAD, align: "left", valign: "bottom", margin: 0, prompt: "Titolo della sezione" }),
      ph("sottotitolo", "body", { x: 4.8, y: 3.85, w: 7.9, h: 1.0, fontSize: 20, color: HEX.grigio, fontFace: BODY, align: "left", valign: "top", margin: 0, prompt: "Domanda guida o sottotitolo" }),
      dots(4.8, 1.95), ...footer(false)], slideNumber: slideNum });
  sezione("Petrolio", HEX.petrolio, HEX.zafferano, [imgH("archi", 0.6, 5.0, 1.4)]);
  ASPETTI_LAYOUT.forEach((k) => sezione("Aspetto " + k, ASP[k].fill, "FFFFFF", [imgH("icona_" + k + "_bianca", 0.6, 1.0, 1.0)]));

  pres.defineSlideMaster({ title: "UNESCO Contenuto", background: { color: "FFFFFF" },
    objects: [dots(0.6, 0.3), ph("title", "title", TITLE),
      ph("body", "body", { x: 0.6, y: 1.55, w: 12.13, h: 5.2, fontSize: 18, color: HEX.testo, fontFace: BODY, valign: "top", margin: 0, paraSpaceAfter: 8, prompt: "Testo o elenco puntato" }), ...footer(false)], slideNumber: slideNum });
  pres.defineSlideMaster({ title: "UNESCO Due colonne", background: { color: "FFFFFF" },
    objects: [dots(0.6, 0.3), ph("title", "title", TITLE),
      ph("body", "body", { x: 0.6, y: 1.55, w: 6.2, h: 5.2, fontSize: 17, color: HEX.testo, fontFace: BODY, valign: "top", margin: 0, paraSpaceAfter: 6, prompt: "Testo (a destra una figura o un box)" }), ...footer(false)], slideNumber: slideNum });
  pres.defineSlideMaster({ title: "UNESCO Definizione", background: { color: "FFFFFF" },
    objects: [{ rect: { x: 6.9, y: 0, w: 6.433, h: 6.85, fill: { color: HEX.fondo2 } } },
      dots(0.6, 0.3), ph("title", "title", { ...TITLE, w: 5.9, prompt: "Titolo" }),
      ph("body", "body", { x: 0.6, y: 1.55, w: 5.9, h: 5.2, fontSize: 16, color: HEX.testo, fontFace: BODY, valign: "top", margin: 0, paraSpaceAfter: 6, prompt: "Testo di contesto" }),
      ph("def_titolo", "body", { x: 7.45, y: 0.5, w: 5.4, h: 0.8, fontSize: 28, bold: true, color: HEX.petrolio, fontFace: HEAD, valign: "middle", margin: 0, prompt: "Definizione" }),
      ph("fonte", "body", { x: 7.45, y: 5.75, w: 5.4, h: 0.9, fontSize: 12, italic: true, color: HEX.grigio, fontFace: BODY, valign: "top", margin: 0, prompt: "Fonte" }),
      ...footer(false)], slideNumber: slideNum });
  pres.defineSlideMaster({ title: "UNESCO Box", background: { color: "FFFFFF" },
    objects: [dots(0.6, 0.3), ph("title", "title", TITLE), { rect: { x: 0.6, y: 1.55, w: 12.13, h: 5.2, fill: { color: HEX.zafferanoChiaro }, rectRadius: 0.18 } },
      ph("box_titolo", "body", { x: 1.0, y: 1.75, w: 11.33, h: 0.6, fontSize: 22, bold: true, color: HEX.petrolio, fontFace: HEAD, align: "left", valign: "middle", margin: 0, prompt: "Titolo del riquadro" }),
      ph("body", "body", { x: 1.0, y: 2.5, w: 11.33, h: 4.0, fontSize: 16, color: HEX.testo, fontFace: BODY, valign: "top", margin: 0, paraSpaceAfter: 6, prompt: "Testo del riquadro" }), ...footer(false)], slideNumber: slideNum });
  pres.defineSlideMaster({ title: "UNESCO Solo titolo", background: { color: "FFFFFF" }, objects: [dots(0.6, 0.3), ph("title", "title", TITLE), ...footer(false)], slideNumber: slideNum });
  pres.defineSlideMaster({ title: "UNESCO Citazione", background: { color: "FFFFFF" },
    objects: [imgH("archi", 0.75, 2.0, 0.9), { line: { x: 2.55, y: 2.0, w: 0, h: 3.4, line: { color: HEX.zafferano, width: 2 } } },
      ph("citazione", "body", { x: 2.9, y: 1.9, w: 9.6, h: 2.9, fontSize: 26, italic: true, color: HEX.petrolio, fontFace: HEAD, valign: "top", margin: 0, prompt: "Testo della citazione" }),
      ph("autore", "body", { x: 2.9, y: 4.95, w: 9.6, h: 0.6, fontSize: 16, bold: true, color: HEX.link, fontFace: BODY, valign: "top", margin: 0, prompt: "– Fonte" }), ...footer(false)], slideNumber: slideNum });
  pres.defineSlideMaster({ title: "UNESCO Chiusura", background: { color: HEX.petrolio },
    objects: [imgH("archi", 10.0, 0.7, 1.6),
      ph("title", "title", { x: 0.8, y: 0.9, w: 9.0, h: 1.2, fontSize: 44, bold: true, color: "FFFFFF", fontFace: HEAD, align: "left", valign: "middle", margin: 0, prompt: "Grazie" }),
      ph("body", "body", { x: 0.8, y: 2.3, w: 9.0, h: 1.6, fontSize: 18, color: "FFFFFF", fontFace: BODY, valign: "top", margin: 0, prompt: "Contatti, prossimi passi" }),
      ph("licenza", "body", { x: 0.8, y: 4.15, w: 11.7, h: 2.6, fontSize: 11, color: HEX.celeste, fontFace: BODY, valign: "top", margin: 0, prompt: "Fonti, licenza e clausola di traduzione" }), ...footer(true)] });

  // ---- helper per i contenuti ----
  const T = (s, text, o) => s.addText(text, { isTextBox: true, margin: 0, fontFace: BODY, color: HEX.testo, ...o });
  const numSq = (s, n, x, y, sz, fill, on) => { s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: sz, h: sz, fill: { color: fill || HEX.petrolio }, rectRadius: 0.07 }); T(s, String(n), { x, y, w: sz, h: sz, fontSize: sz > 0.45 ? 17 : 15, bold: true, color: on || "FFFFFF", align: "center", valign: "middle", fontFace: HEAD }); };
  const pill = (s, text, x, y, w, fill, on, fs) => { s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h: 0.36, fill: { color: fill }, rectRadius: 0.18 }); T(s, text, { x, y, w, h: 0.36, fontSize: fs || 13, bold: true, color: on, align: "center", valign: "middle" }); };
  const card = (s, x, y, w, h, o = {}) => s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, fill: { color: o.fill || "FFFFFF" }, line: o.noLine ? { type: "none" } : { color: o.line || HEX.linea, width: 0.75 }, rectRadius: 0.12 });
  const icon = (s, k, x, y, sz, variant) => s.addImage({ path: IMG + "icona_" + ASP[k].icona + (variant ? "_" + variant : "") + ".png", x, y, w: sz, h: sz });
  const livello = (s, n, x, y, h) => s.addImage({ path: IMG + "livello_" + n + ".png", x, y, h, w: h * 1.5 });
  const fonte = (s, txt, y) => T(s, txt, { x: 0.6, y: y || 6.5, w: 12.13, h: 0.3, fontSize: 11, italic: true, color: HEX.grigio });
  const img = (s, file, x, y, w, h) => s.addImage({ path: IMG + file, x, y, w, h });
  return { pres, T, numSq, pill, card, icon, livello, fonte, img, HEX, ASP, THEME, W, H, DIMS };
}
module.exports = { makeKit, HEX, ASP, THEME, KIT, IMG };
