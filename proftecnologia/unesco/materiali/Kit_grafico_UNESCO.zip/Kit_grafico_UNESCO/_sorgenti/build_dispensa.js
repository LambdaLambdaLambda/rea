// Kit grafico UNESCO IA — converte un file Markdown in una dispensa Word A4 con lo stile del kit (docx)
// uso: node build_dispensa.js uscita.docx sorgente.md
// Sintassi riconosciuta: # titolo – sottotitolo · *riga metadati* · --- (nuova pagina) · ## NN · Capitolo · ## / ### / #### titoli
// > **Titolo box** sottotitolo (riquadro; colore dal titolo) · > testo (citazione) · - elenco · 1. elenco numerato (quadrati petrolio)
// | tabelle | (prima colonna colorata se è un aspetto o un livello) · ![didascalia](nome_immagine_in_img)
const fs = require("fs");
const D = require("docx");
const { Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  AlignmentType, HeadingLevel, LevelFormat, Footer, PageNumber, TabStopType, VerticalAlign } = D;
const { HEX, ASP, LIVELLI, ATTR } = require("./palette.js");
const DIMS = require(__dirname + "/dims.json");
const IMG = __dirname + "/../img/";
const OUT = process.argv[2] || "dispensa.docx";
const MDFILE = process.argv[3] || __dirname + "/esempio_dispensa.md";
const HEAD = "Outfit", BODY = "Source Sans 3";
const PAGE_W = 11906, MARG = 1134, TW = PAGE_W - 2 * MARG; // A4, margini 2 cm

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB, insideHorizontal: NB, insideVertical: NB };
const r = (text, o = {}) => new TextRun({ text, ...o });
const P = (children, o = {}) => new Paragraph({ children: Array.isArray(children) ? children : [typeof children === "string" ? r(children) : children], ...o });
const cell = (children, o = {}) => new TableCell({ children, ...o });
const shade = (fill) => ({ fill, type: ShadingType.CLEAR, color: "auto" });
const image = (name, wPx, align = AlignmentType.CENTER) => {
  const [iw, ih] = DIMS[name];
  return new Paragraph({ alignment: align, keepNext: true, spacing: { before: 120, after: 80 }, children: [new ImageRun({ type: "png", data: fs.readFileSync(IMG + name + ".png"), transformation: { width: wPx, height: Math.round(wPx * ih / iw) }, altText: { title: name, description: name.replace(/_/g, " "), name } })] });
};
// testo con **grassetto** e *corsivo*
const inl = (t, base = {}) => t.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/).filter(Boolean).map((seg) =>
  seg.startsWith("**") ? r(seg.slice(2, -2), { ...base, bold: true }) : (seg.startsWith("*") && seg.length > 2 ? r(seg.slice(1, -1), { ...base, italics: true }) : r(seg, base)));

// Riquadro a una cella
const box = (fill, title, sub, paras) => new Table({
  width: { size: TW, type: WidthType.DXA }, columnWidths: [TW], borders: noBorders,
  rows: [new TableRow({ cantSplit: paras.length < 9, children: [cell([
    P(r(title, { font: HEAD, bold: true, size: 26, color: HEX.petrolio }), { style: "BoxTitolo" }),
    ...(sub ? [P(inl(sub, { italics: true, size: 19, color: HEX.grigio }), { alignment: AlignmentType.LEFT, spacing: { after: 120 } })] : []),
    ...paras], { width: { size: TW, type: WidthType.DXA }, shading: shade(fill), margins: { top: 200, bottom: 160, left: 280, right: 280 } })] })],
});
// Apertura di capitolo: linguetta petrolio con numero zafferano + titolo + simbolo degli aspetti
const capitolo = (num, titolo) => [
  new Table({ width: { size: 1700, type: WidthType.DXA }, columnWidths: [1700], borders: noBorders, alignment: AlignmentType.CENTER,
    rows: [new TableRow({ cantSplit: true, children: [cell([P(r(num, { font: HEAD, bold: true, size: 60, color: HEX.zafferano }), { alignment: AlignmentType.CENTER, spacing: { before: 0, after: 0 } })],
      { width: { size: 1700, type: WidthType.DXA }, shading: shade(HEX.petrolio), margins: { top: 80, bottom: 80 } })] })] }),
  new Paragraph({ heading: HeadingLevel.HEADING_1, alignment: AlignmentType.CENTER, children: [r(titolo)] }),
  image("simbolo_aspetti", 90),
];
// Elenco numerato con quadrati petrolio
const numerato = (items) => {
  const nW = 520, gap = 160, tW = TW - nW - gap;
  const sep = { style: BorderStyle.SINGLE, size: 4, color: HEX.linea };
  return new Table({ width: { size: TW, type: WidthType.DXA }, columnWidths: [nW, gap, tW], borders: noBorders,
    rows: items.map((t, i) => new TableRow({ cantSplit: true, children: [
      cell([P(r(String(i + 1), { bold: true, color: "FFFFFF", size: 22, font: HEAD }), { alignment: AlignmentType.CENTER, spacing: { before: 0, after: 0 } })], { width: { size: nW, type: WidthType.DXA }, shading: shade(HEX.petrolio), verticalAlign: VerticalAlign.CENTER, margins: { top: 40, bottom: 40 }, borders: { top: { style: BorderStyle.SINGLE, size: 24, color: "FFFFFF" }, bottom: { style: BorderStyle.SINGLE, size: 24, color: "FFFFFF" }, left: NB, right: NB } }),
      cell([P("")], { width: { size: gap, type: WidthType.DXA } }),
      cell([P(inl(t), { alignment: AlignmentType.LEFT, spacing: { before: 60, after: 60 } })], { width: { size: tW, type: WidthType.DXA }, verticalAlign: VerticalAlign.CENTER, borders: { bottom: sep, top: NB, left: NB, right: NB } }),
    ] })) });
};
// Tabelle: intestazione petrolio; prima colonna colorata per aspetti, livelli e codici dei blocchi
const NOMI = {}; Object.values(ASP).forEach((a) => { NOMI[a.nome] = a; });
const LIV = new Set([...LIVELLI.studenti, ...LIVELLI.docenti]);
const aspDaCodice = (c) => { // 4.1.2 -> aspetto 2 studenti; 3.2 -> aspetto 3 docenti
  let m = c.match(/^4\.\d\.(\d)$/); if (m) return ASP[["mentalita", "etica", "tecniche", "progettazione"][m[1] - 1]];
  m = c.match(/^(\d)\.\d$/); if (m) return ASP[["mentalita", "etica", "fondamenti", "pedagogia", "sviluppo"][m[1] - 1]];
  return null;
};
const table = (rows) => {
  const head = rows[0], data = rows.slice(1), n = head.length;
  let ws;
  if (n === 2) ws = head[0] === "Codice" ? [1300, TW - 1300] : [2000, TW - 2000];
  else if (n === 3 && head[0] === "Codice") ws = [900, 2700, TW - 3600];
  else if (n === 3) ws = [1900, Math.floor((TW - 1900) / 2), TW - 1900 - Math.floor((TW - 1900) / 2)];
  else { const f = 2400, o = Math.floor((TW - f) / (n - 1)); ws = [f, ...Array(n - 1).fill(o)]; ws[n - 1] = TW - f - o * (n - 2); }
  const bd = { style: BorderStyle.SINGLE, size: 4, color: HEX.linea };
  const mk = (txt, i, isHead) => {
    let fill, color = HEX.testo, bold = isHead || i === 0;
    if (isHead) { fill = HEX.petrolio; color = "FFFFFF"; }
    else if (i === 0) {
      const a = NOMI[txt] || aspDaCodice(txt);
      if (a) { fill = a.soft; color = a.fill; } else if (LIV.has(txt)) { fill = HEX.zafferanoChiaro; color = HEX.petrolio; } else fill = HEX.fondo;
    }
    return cell([P(inl(txt, { size: 19, bold: bold || undefined, color, font: i === 0 || isHead ? HEAD : BODY }), { alignment: AlignmentType.LEFT, spacing: { before: 0, after: 0, line: 264, lineRule: D.LineRuleType.AUTO } })],
      { width: { size: ws[i], type: WidthType.DXA }, shading: fill ? shade(fill) : undefined, margins: { top: 80, bottom: 80, left: 120, right: 120 }, verticalAlign: VerticalAlign.CENTER });
  };
  return new Table({ width: { size: TW, type: WidthType.DXA }, columnWidths: ws, borders: { top: bd, bottom: bd, left: bd, right: bd, insideHorizontal: bd, insideVertical: bd },
    rows: [new TableRow({ tableHeader: true, cantSplit: true, children: head.map((h, i) => mk(h, i, true)) }), ...data.map((rw) => new TableRow({ cantSplit: true, children: rw.map((c, i) => mk(c, i, false)) }))] });
};
const boxFill = (t) => /Attività|Proposta/i.test(t) ? HEX.zafferanoChiaro : /Attenzione|Definizione/i.test(t) ? HEX.acquaChiara : HEX.fondo2;
const pageBreak = () => new Paragraph({ pageBreakBefore: true, spacing: { before: 0, after: 0, line: 120, lineRule: D.LineRuleType.EXACT }, children: [] });
const bullet = (t, o = {}) => new Paragraph({ numbering: { reference: "punti", level: 0 }, alignment: /http/.test(t) ? AlignmentType.LEFT : AlignmentType.JUSTIFIED, children: inl(t), ...o });

// ===== Contenuto =====
const MD = fs.readFileSync(MDFILE, "utf8").split("\n");
const children = [];
const titolo = MD[0].replace(/^# /, "").split(" – ");
children.push(new Table({ width: { size: TW, type: WidthType.DXA }, columnWidths: [TW], borders: noBorders,
  rows: [new TableRow({ cantSplit: true, children: [cell([
    P(r(titolo[0], { font: HEAD, bold: true, size: 56, color: "FFFFFF" }), { style: "TitoloDispensa" }),
    ...(titolo[1] ? [P(r(titolo[1], { size: 26, color: HEX.celeste }), { spacing: { before: 160, after: 0 }, alignment: AlignmentType.LEFT })] : []),
  ], { width: { size: TW, type: WidthType.DXA }, shading: shade(HEX.petrolio), margins: { top: 440, bottom: 440, left: 440, right: 440 } })] })] }));
children.push(image("archi", 150));
let i = 1;
while (i < MD.length) {
  const L = MD[i];
  if (!L.trim()) { i++; continue; }
  if (L.startsWith("---")) { children.push(pageBreak()); i++; continue; }
  let m;
  if ((m = L.match(/^## (\d\d) · (.*)/))) { children.push(...capitolo(m[1], m[2])); i++; continue; }
  if (L.startsWith("#### ")) { const t = L.slice(5), a = Object.values(ASP).find((x) => t.startsWith(x.nome)); children.push(new Paragraph({ heading: HeadingLevel.HEADING_3, children: [r(t, a ? { color: a.fill } : {})] })); i++; continue; }
  if (L.startsWith("### ")) { children.push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: [r(L.slice(4))] })); i++; continue; }
  if (L.startsWith("## ")) { children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, children: [r(L.slice(3))] })); i++; continue; }
  if ((m = L.match(/^!\[(.*)\]\((.*)\)/))) {
    children.push(image(m[2], 600));
    children.push(P(r(m[1], { italics: true, size: 17, color: HEX.grigio }), { style: "Didascalia", spacing: { after: 200 } }));
    i++; continue;
  }
  if (L.startsWith("|")) {
    const rows = [];
    while (i < MD.length && MD[i].startsWith("|")) { if (!/^\|[-| ]+\|$/.test(MD[i])) rows.push(MD[i].slice(1, -1).split("|").map((x) => x.trim())); i++; }
    children.push(table(rows)); children.push(P("", { spacing: { after: 80 } })); continue;
  }
  if (L.startsWith(">")) {
    const q = [];
    while (i < MD.length && MD[i].startsWith(">")) { q.push(MD[i].replace(/^> ?/, "")); i++; }
    const mt = q[0].match(/^\*\*(.+?)\*\*\s*(.*)$/);
    if (mt) {
      const paras = [];
      q.slice(1).forEach((x) => {
        if (!x.trim()) return;
        if (x.startsWith("- ")) paras.push(bullet(x.slice(2), { alignment: AlignmentType.LEFT }));
        else if (/^\d+\. /.test(x)) paras.push(new Paragraph({ alignment: AlignmentType.LEFT, indent: { left: 400, hanging: 400 }, spacing: { after: 100 }, children: [r(x.match(/^\d+/)[0] + ".  ", { bold: true, color: HEX.petrolio, font: HEAD }), ...inl(x.replace(/^\d+\. /, ""))] }));
        else paras.push(P(inl(x), { alignment: AlignmentType.JUSTIFIED }));
      });
      children.push(box(boxFill(mt[1]), mt[1], mt[2], paras));
      children.push(P("", { spacing: { after: 80 } }));
    } else q.forEach((x) => children.push(new Paragraph({ style: "Citazione", children: [r(x.replace(/\*/g, ""))] })));
    continue;
  }
  if (L.startsWith("- ")) { while (i < MD.length && MD[i].startsWith("- ")) { children.push(bullet(MD[i].slice(2))); i++; } continue; }
  if (/^\d+\. /.test(L)) {
    const items = [];
    while (i < MD.length && /^\d+\. /.test(MD[i])) { items.push(MD[i].replace(/^\d+\. /, "")); i++; }
    children.push(numerato(items)); children.push(P("", { spacing: { after: 80 } })); continue;
  }
  const isMeta = i < 4 && L.startsWith("*");
  children.push(P(inl(L, isMeta ? { color: HEX.grigio } : {}), { alignment: isMeta ? AlignmentType.LEFT : AlignmentType.JUSTIFIED, spacing: { before: isMeta ? 240 : 0, after: 140 }, keepNext: /:\s*$/.test(L) }));
  i++;
}

const doc = new Document({
  creator: "Antonio Scaramuzzino", title: titolo[0],
  styles: {
    default: { document: { run: { font: BODY, size: 21, color: HEX.testo } } },
    paragraphStyles: [
      { id: "Normal", name: "Normal", run: { font: BODY, size: 21, color: HEX.testo }, paragraph: { spacing: { after: 140, line: 288, lineRule: D.LineRuleType.AUTO }, alignment: AlignmentType.JUSTIFIED } },
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: HEAD, size: 40, bold: true, color: HEX.petrolio }, paragraph: { spacing: { before: 160, after: 120 }, alignment: AlignmentType.CENTER, outlineLevel: 0, keepNext: true } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: HEAD, size: 28, bold: true, color: HEX.petrolio }, paragraph: { spacing: { before: 300, after: 140 }, alignment: AlignmentType.LEFT, outlineLevel: 1, keepNext: true } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: HEAD, size: 23, bold: true, color: HEX.link }, paragraph: { spacing: { before: 220, after: 80 }, alignment: AlignmentType.LEFT, outlineLevel: 2, keepNext: true } },
      { id: "TitoloDispensa", name: "UNESCO Titolo dispensa", basedOn: "Normal", run: { font: HEAD, size: 56, bold: true, color: "FFFFFF" }, paragraph: { spacing: { after: 0, line: 240, lineRule: D.LineRuleType.AUTO }, alignment: AlignmentType.LEFT } },
      { id: "BoxTitolo", name: "UNESCO Titolo riquadro", basedOn: "Normal", run: { font: HEAD, size: 26, bold: true, color: HEX.petrolio }, paragraph: { spacing: { before: 0, after: 100 }, alignment: AlignmentType.LEFT } },
      { id: "Citazione", name: "UNESCO Citazione", basedOn: "Normal", quickFormat: true, run: { font: HEAD, italics: true, size: 23, color: HEX.petrolio }, paragraph: { indent: { left: 360 }, spacing: { before: 120, after: 120 }, border: { left: { style: BorderStyle.SINGLE, size: 12, color: HEX.zafferano, space: 12 } }, alignment: AlignmentType.LEFT } },
      { id: "Didascalia", name: "UNESCO Didascalia", basedOn: "Normal", quickFormat: true, run: { italics: true, size: 17, color: HEX.grigio }, paragraph: { alignment: AlignmentType.CENTER } },
    ],
  },
  numbering: { config: [{ reference: "punti", levels: [{ level: 0, format: LevelFormat.BULLET, text: "–", alignment: AlignmentType.LEFT, style: { run: { bold: true, color: HEX.zafferano }, paragraph: { indent: { left: 400, hanging: 280 } } } }] }] },
  sections: [{
    properties: { page: { size: { width: PAGE_W, height: 16838 }, margin: { top: MARG, bottom: MARG, left: MARG, right: MARG, footer: 500 } } },
    footers: { default: new Footer({ children: [new Paragraph({ tabStops: [{ type: TabStopType.RIGHT, position: TW }], alignment: AlignmentType.LEFT, children: [
      r(ATTR, { italics: true, size: 14, color: HEX.grigio }), r("\t"), new TextRun({ children: [PageNumber.CURRENT], bold: true, size: 18, color: HEX.petrolio, font: HEAD })] })] }) },
    children,
  }],
});
Packer.toBuffer(doc).then((b) => { fs.writeFileSync(OUT, b); console.log("ok", OUT); });
